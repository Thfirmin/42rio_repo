Cronologia:
I. Eu Aceito;
II. Shell (00 e 01);
III. C (00 até 02);
IV. Rush00;
V. C (03 até 06);
VI. Rush01;
VII. C (07 até 10);
VIII. Rush02;
IX. C (11 até 13);
X. Projeto final BSQ.