void ft_is_negative(int n);

int	main(void)
{
	ft_is_negative(-6);
	return(0);
}
