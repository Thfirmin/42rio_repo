void ft_putchar(char c);

int	main(void)
{
	ft_putchar('g');
	return(0);
}
