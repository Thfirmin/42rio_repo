/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thfirmin <thiagofirmino2001@gmail.com>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/17 04:13:26 by Mhenriqu          #+#    #+#             */
/*   Updated: 2022/02/17 18:43:59 by thfirmin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_print_comb(void)
{
	char	p;
	char	s;
	char	t;

	p = 48;
	while (p <= 57)
	{
		s = p + 1;
		while (s <= 57)
		{
			t = s + 1;
			while (t <= 57)
			{
				ft_putchar(p);
				ft_putchar(s);
				ft_putchar(t);
				if (p != 55)
				{
					ft_putchar(',');
					ft_putchar(' ');
				}
				t++;
			}
		s++;
		}
	p++;
	}
}

int	main(void)
{
	ft_print_comb();
}
