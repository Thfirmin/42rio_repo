/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncmp.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thfirmin <thiagofirmino2001@gmail.com>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/15 15:31:46 by vidos-sa          #+#    #+#             */
/*   Updated: 2022/02/18 23:57:57 by thfirmin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strncmp(char *s1, char *s2, unsigned int n)
{
	unsigned int	cnt;

	cnt = 0;
	if (n <= cnt)
		return (0);
	while (cnt < n - 1
		&& s1[cnt] != '\0'
		&& s2[cnt] != '\0'
		&& s1[cnt] == s2[cnt])
	{
		cnt++;
	}
	return (s1[cnt] - s2[cnt]);
}

#include <string.h>
#include <stdio.h>
int	main(void)
{
	char val1[]= "abc";
	char val2[]= "dba";
	int ret = strncmp(val1, val2, 2);
	
	//int ret = ft_strncmp(val1, val2, 2);
	printf("%d.\n", ret);
	return(0);
}
