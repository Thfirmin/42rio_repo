/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thfirmin <thiagofirmino2001@gmail.com>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/15 15:31:46 by vidos-sa          #+#    #+#             */
/*   Updated: 2022/02/18 23:50:07 by thfirmin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcat(char *dest, char *src)
{
	int	cd;
	int	cs;

	cd = 0;
	cs = 0;
	while (dest[cd])
		cd++;
	while (src[cs])
	{
		dest[cd] = src[cs];
		cs++;
		cd++;
	}
	dest[cd] = '\0';
	return (dest);
}

// #include <string.h>
#include <stdio.h>
int	main(void)
{
	char vd[100]="Our destiny awaits ";
	char vs[100]="at 42 Rio";
	// strcat(vd, vs);
	ft_strcat(vd, vs);
	printf("%s.\n", vd);
	return(0);
}
