/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thfirmin <thiagofirmino2001@gmail.com>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/15 15:31:46 by vidos-sa          #+#    #+#             */
/*   Updated: 2022/02/19 00:03:58 by thfirmin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strstr(char *str, char *to_find)
{
	int	cs;
	int	cf;

	if (to_find[0] == 0)
		return (str);
	cs = 0;
	while (str[cs])
	{
		cf = 0;
		while (str[cs + cf] == to_find[cf])
		{
			cf++;
			if (to_find[cf] == '\0')
				return (&str[cs]);
		}
		cs++;
	}
	return (0);
}

// #include <string.h>
#include <stdio.h>
int	main(void)
{
	char strx[]= "Wait a minute! We will be at 42 Rio";
	char search[]= "";
	char *rsl = ft_strstr(strx, search);
	// char *rsl = strstr(strx, search);
	printf("%s\n", rsl);
	return (0);
}
