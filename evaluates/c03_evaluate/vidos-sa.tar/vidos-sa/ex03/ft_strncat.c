/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thfirmin <thiagofirmino2001@gmail.com>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/15 15:31:46 by vidos-sa          #+#    #+#             */
/*   Updated: 2022/02/19 00:01:17 by thfirmin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int	cd;
	unsigned int	cs;

	cd = 0;
	while (dest[cd])
	{
		cd++;
	}
	cs = 0;
	while (src[cs] != '\0' && cs < nb)
	{
		dest[cd] = src[cs];
		cs++;
		cd++;
	}
	dest[cd] = '\0';
	return (dest);
}

// #include <string.h>
#include <stdio.h>
int	main(void)
{
	char vd[100]="Our destiny awaits ";
	char vs[100]="at 42 Rio";
	// strncat(vd, vs, 5);
	ft_strncat(vd, vs, 7);
	printf("%s.\n", vd);
	return(0);
}
