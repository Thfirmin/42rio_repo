/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thfirmin <thiagofirmino2001@gmail.com>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/15 15:31:46 by vidos-sa          #+#    #+#             */
/*   Updated: 2022/02/18 23:52:22 by thfirmin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_strcmp(char *s1, char *s2)
{
	int	cnt;

	cnt = 0;
	while (s1[cnt] != '\0' && s2[cnt] != '\0' && s1[cnt] == s2[cnt])
	{
		cnt++;
	}
	return (s1[cnt] - s2[cnt]);
}

#include <string.h>
#include <stdio.h>
int	main(void)
{
	int ret;
	char val1[]= "abc";
	char val2[]= "abd";
	ret = strcmp(val1, val2);
	printf("%d.\n", ret);
	strcpy (val1, "abc");
	strcpy (val2, "abd");
	ret = ft_strcmp(val1, val2);
	printf("%d.\n", ret);
	return(0);
}
