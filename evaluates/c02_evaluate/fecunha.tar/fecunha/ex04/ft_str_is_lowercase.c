/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fecunha <fecunha@student.42.rio>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/18 06:55:51 by fecunha           #+#    #+#             */
/*   Updated: 2022/02/18 16:18:56 by fecunha          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_lowercase(char *str)
{
	while (*str != '\0')
	{
		if (!(*str >= 'a' && *str <= 'z'))
			return (0);
		str++;
	}
	return (1);
}

/* #include <stdio.h>
int main(void)
{
	int i;
	char src[] = {"a"};
	i = ft_str_is_lowercase(src);
	printf("Retorno da string passada: %d\n", i);
	return(0);
} */