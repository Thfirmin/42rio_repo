/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_printable.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fecunha <fecunha@student.42.rio>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/18 07:43:56 by fecunha           #+#    #+#             */
/*   Updated: 2022/02/18 16:44:45 by fecunha          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_printable(char *str)
{
	while (*str != '\0')
	{
		if (!(*str >= 32 && *str <= 126))
			return (0);
		str++;
	}
	return (1);
}

/* #include <stdio.h>
int main(void)
{
	int i;
	char src[] = {"\n"};
	i = ft_str_is_printable(src);
	printf("Retorno da string passada: %d\n", i);
	return(0);
} */