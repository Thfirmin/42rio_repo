/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fecunha <fecunha@student.42.rio>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/17 20:24:06 by fecunha           #+#    #+#             */
/*   Updated: 2022/02/18 07:33:41 by fecunha          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_numeric(char *str)
{
	while (*str != '\0')
	{
		if (!(*str >= '0' && *str <= '9'))
		{
			return (0);
		}
		str++;
	}
	return (1);
}

/* #include <stdio.h>
int	main(void)
{
	int i;
	char src[] = {""};
	i = ft_str_is_numeric(src);
	printf("Retorno da string passada: %i\n", i);
	return(0);
} */