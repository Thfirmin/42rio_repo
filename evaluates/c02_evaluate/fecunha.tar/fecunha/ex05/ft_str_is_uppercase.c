/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_uppercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: fecunha <fecunha@student.42.rio>           +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/18 07:43:33 by fecunha           #+#    #+#             */
/*   Updated: 2022/02/18 07:43:38 by fecunha          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_uppercase(char *str)
{
	while (*str != '\0')
	{
		if (!(*str >= 'A' && *str <= 'Z'))
			return (0);
		str++;
	}
	return (1);
}

/* #include <stdio.h>
int main(void)
{
	int i;
	char src[] = {"AAaAA"};
	i = ft_str_is_uppercase(src);
	printf("Retorno da string passada: %d\n", i);
	return(0);
} */