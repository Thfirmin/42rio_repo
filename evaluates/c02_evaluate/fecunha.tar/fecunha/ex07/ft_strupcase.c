/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thfirmin <thiagofirmino2001@gmail.com>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/18 07:48:04 by fecunha           #+#    #+#             */
/*   Updated: 2022/02/19 00:42:59 by thfirmin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strupcase(char *str)
{
	int	count;

	count = 0;
	while (str[count] != '\0')
	{
		if (str[count] >= 'a' && str[count] <= 'z')
		{
			str[count] = str[count] - 32;
		}
	count++;
	}
	return (str);
}

#include <stdio.h>
int main(void)
{
	char src[] = {"aB1cd"};
	printf("Retorno da main: %s\n", src);
	ft_strupcase(src);
	printf("Retorno ft_strupcase: %s\n", src);
	return(0);
}