/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thfirmin <thiagofirmino2001@gmail.com>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/18 05:40:58 by fecunha           #+#    #+#             */
/*   Updated: 2022/02/19 00:37:01 by thfirmin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strcpy(char *dest, char *src)
{
	int	count;

	count = 0;
	while (src[count] != '\0')
	{
		dest[count] = src[count];
		count++;
	}	
	dest[count] = '\0';
	return (dest);
}

/* #include <stdio.h>
int	main(void)
{
	char src[] = "Continue";
	char dest[] = "a nadar";
	ft_strcpy(dest, src);
	printf("Retorno: %s\n", dest);
	return(0);
} */
