/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thfirmin <thiagofirmino2001@gmail.com>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/18 02:53:31 by fecunha           #+#    #+#             */
/*   Updated: 2022/02/19 00:43:49 by thfirmin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

char	*ft_strlowcase(char *str)
{
	int	count;

	count = 0;
	while (str[count] != '\0')
	{
		if (str[count] >= 'A' && str[count] <= 'Z')
		{
			str[count] = str[count] + 32;
		}
		count++;
	}	
	return (str);
}

#include <stdio.h>
int main(void)
{
	char src[] = {"aB1 Cd"};
	printf("Retorno da main: %s\n", src);
	ft_strlowcase(src);
	printf("Retorno ft_strupcase: %s\n", src);
	return(0);
}