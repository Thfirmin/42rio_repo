/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thfirmin <thiagofirmino2001@gmail.com>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/17 20:22:18 by fecunha           #+#    #+#             */
/*   Updated: 2022/02/19 00:37:25 by thfirmin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

int	ft_str_is_alpha(char *str)
{
	while (*str != '\0')
	{
		if (!((*str >= 'a' && *str <= 'z')
				|| (*str >= 'A' && *str <= 'Z' )))
			return (0);
		str++;
	}
	return (1);
}

#include <stdio.h>
int main(void)
{
	int i;
	char src[] = {"aB cd"};
	i = ft_str_is_alpha(src);
	printf("Retorno da string passada: %d\n", i);
	return(0);
}