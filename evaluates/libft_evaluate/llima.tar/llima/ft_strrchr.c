/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strrchr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llima <llima@student.42.rio>               +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/03 04:49:40 by llima             #+#    #+#             */
/*   Updated: 2022/06/03 04:50:27 by llima            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strrchr(const char *s, int c)
{
	const char	*p;

	p = s;
	while (*s != '\0')
	{
		if (*s == (char) c)
			p = s;
		s++;
	}
	if (c == '\0')
		return ((char *) s);
	if (*p == (char) c)
		return ((char *) p);
	return (NULL);
}
