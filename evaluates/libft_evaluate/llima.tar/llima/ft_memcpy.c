/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llima <llima@student.42.rio>               +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/03 04:22:48 by llima             #+#    #+#             */
/*   Updated: 2022/06/03 05:03:27 by llima            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memcpy(void *dest, const void *src, size_t n)
{
	char	*str;

	str = dest;
	if (dest == NULL && src == NULL)
		return (NULL);
	while (n--)
	{
		*(char *) str++ = *(char *) src++;
	}
	return (dest);
}
