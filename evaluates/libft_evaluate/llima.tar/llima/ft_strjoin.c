/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strjoin.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llima <llima@student.42.rio>               +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/03 04:36:15 by llima             #+#    #+#             */
/*   Updated: 2022/06/03 04:38:21 by llima            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strjoin(char const *s1, char const *s2)
{
	char			*s3;
	unsigned int	lens1;
	unsigned int	lens2;
	unsigned int	i;

	lens1 = ft_strlen(s1);
	lens2 = ft_strlen(s2);
	i = 0;
	s3 = malloc(lens1 + lens2 + 1);
	if (s3 == NULL)
		return (NULL);
	while (i <= lens1)
	{
		if (ft_strlen(s1) > i)
			s3[i] = s1[i];
		if (lens2 > i)
		{
			s3[lens1] = s2[i];
			lens1++;
		}
		i++;
	}
	s3[i - 1] = '\0';
	return (s3);
}
