/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strtrim.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llima <llima@student.42.rio>               +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/03 04:50:46 by llima             #+#    #+#             */
/*   Updated: 2022/06/03 04:51:59 by llima            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strtrim(char const *s1, char const *set)
{
	unsigned int	i;
	unsigned int	j;
	unsigned int	lens1;

	i = 0;
	j = 0;
	lens1 = ft_strlen(s1) - 1;
	if (ft_strlen(s1) == 0)
		return (ft_substr(s1, 0, 0));
	while (i < ft_strlen(set))
	{
		while (s1[j] == set[i] || s1[lens1] == set[i])
		{
			if (s1[j] == set[i])
				j++;
			if (j > lens1)
				return (ft_substr(s1, 0, 0));
			if (s1[lens1] == set[i])
				lens1--;
			i = 0;
		}
		i++;
	}
	return (ft_substr(s1, j, lens1 - j + 1));
}
