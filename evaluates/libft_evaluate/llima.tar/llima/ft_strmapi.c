/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strmapi.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llima <llima@student.42.rio>               +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/03 04:42:37 by llima             #+#    #+#             */
/*   Updated: 2022/06/03 04:44:27 by llima            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strmapi(char const *s, char (*f)(unsigned int, char))
{
	unsigned int	i;
	char			*final_str;

	i = 0;
	final_str = ft_strdup((char *) s);
	if (!final_str)
		return (NULL);
	while (i < ft_strlen(s))
	{
		final_str[i] = (f)(i, s[i]);
		i++;
	}
	return (final_str);
}
