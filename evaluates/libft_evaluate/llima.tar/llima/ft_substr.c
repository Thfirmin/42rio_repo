/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_substr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llima <llima@student.42.rio>               +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/03 04:52:25 by llima             #+#    #+#             */
/*   Updated: 2022/06/06 23:30:36 by llima            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_substr(char const *s, unsigned int start, size_t len)
{
	char	*substr;
	size_t	i;
	size_t	slen;

	i = 0;
	slen = ft_strlen(s);
	if (start > slen)
		start = slen;
	if (len > slen - 1 || start == slen)
		len = slen - start;
	substr = malloc(len + 1);
	if (substr == NULL)
		return (NULL);
	while (len > 0)
	{	
		substr[i++] = s[start++];
		len--;
	}
	substr[i] = '\0';
	return (substr);
}
