/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llima <llima@student.42.rio>               +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/03 04:10:06 by llima             #+#    #+#             */
/*   Updated: 2022/06/03 04:20:27 by llima            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int		ft_get_size(long int n);
static long int	ft_set_muldiv(int size_n, int n);
static char		*ft_transform(char *string, long int number, long int muldiv);

char	*ft_itoa(int n)
{
	char		*string;
	long int	muldiv;
	long int	number;

	number = n;
	muldiv = ft_set_muldiv(ft_get_size(number), n);
	string = malloc(ft_get_size(number) + 1);
	if (string == NULL)
		return (NULL);
	return (ft_transform(string, number, muldiv));
}

static int	ft_get_size(long int n)
{
	long int	i;
	int			size;

	i = 1;
	size = 0;
	if (n == 0)
		return (1);
	if (n < 0)
	{
		size++;
		n *= -1;
	}
	while ((n / i) > 0)
	{
		i *= 10;
		size++;
	}
	return (size);
}

static long int	ft_set_muldiv(int size_n, int n)
{
	long int	muldiv;

	muldiv = 1;
	size_n--;
	if (n < 0)
		size_n--;
	while (size_n > 0)
	{
		muldiv *= 10;
		size_n--;
	}
	return (muldiv);
}

static char	*ft_transform(char *string, long int number, long int muldiv)
{
	int	i;

	i = 0;
	if (number < 0)
	{
		number *= -1;
		string[i] = '-';
		i++;
	}
	while (muldiv >= 1)
	{
		string[i] = (number / muldiv) + '0';
		number -= (number / muldiv) * muldiv;
		muldiv /= 10;
		i++;
	}
	string[i] = '\0';
	return (string);
}
