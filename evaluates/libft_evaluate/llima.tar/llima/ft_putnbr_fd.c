/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr_fd.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llima <llima@student.42.rio>               +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/03 04:27:32 by llima             #+#    #+#             */
/*   Updated: 2022/06/03 04:27:47 by llima            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_putnbr_fd(int n, int fd)
{
	char		c;
	long int	number;
	long int	muldiv;

	number = n;
	muldiv = 1;
	if (n < 0)
	{
		number *= -1;
		write (fd, "-", 1);
	}
	while ((number / muldiv) >= 10)
		muldiv *= 10;
	while (muldiv >= 1)
	{
		c = (number / muldiv) + '0';
		number -= (number / muldiv) * muldiv ;
		muldiv /= 10;
		write (fd, &c, 1);
	}
}
