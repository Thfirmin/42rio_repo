/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llima <llima@student.42.rio>               +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/03 04:47:56 by llima             #+#    #+#             */
/*   Updated: 2022/06/03 05:07:17 by llima            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *haytack, const char *needle, size_t len)
{
	if (*needle == '\0')
		return ((char *) haytack);
	while (*haytack != '\0' && len > 0)
	{
		if (ft_strlen(needle) > len)
			break ;
		if (ft_strncmp((char *) haytack, (char *) needle,
				(ft_strlen(needle))) != 0)
		{
			haytack++;
			len--;
		}
		else
			return ((char *) haytack);
	}
	return (NULL);
}
