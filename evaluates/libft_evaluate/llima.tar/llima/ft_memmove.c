/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memmove.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llima <llima@student.42.rio>               +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/03 04:24:08 by llima             #+#    #+#             */
/*   Updated: 2022/06/03 05:04:00 by llima            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memmove(void *dest, const void *src, size_t n)
{
	char	*i_dst;

	i_dst = dest;
	if (dest == NULL && src == NULL)
		return (NULL);
	if (dest < src)
	{
		while (n--)
			*(char *) i_dst++ = *(char *) src++;
		return (dest);
	}
	src += n - 1;
	i_dst += n - 1;
	while (n--)
		*(char *) i_dst-- = *(char *) src--;
	return (dest);
}
