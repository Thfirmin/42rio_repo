/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_split.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llima <llima@student.42.rio>               +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/03 04:29:11 by llima             #+#    #+#             */
/*   Updated: 2022/06/03 05:12:01 by llima            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	ft_get_size(char const *s, int c, int pos);

char	**ft_split(char const *s, char c)
{
	unsigned int	pos;
	unsigned int	arrpos;
	char			**array;

	pos = 0;
	arrpos = 0;
	array = malloc(ft_get_size(s, c, 0) * sizeof(char *));
	if (array == NULL)
		return (NULL);
	while (*s != '\0')
	{
		while (*s == c)
			s++;
		while (s[pos] != c && s[pos] != '\0')
			pos++;
		if (*s != '\0')
		{
		array[arrpos] = ft_substr(s, 0, pos);
		arrpos++;
		}
		s += pos;
		pos = 0;
	}
	array[arrpos] = NULL;
	return (array);
}

static int	ft_get_size(char const *s, int c, int pos)
{
	unsigned int	count;

	count = 1;
	while (s[pos] != '\0')
	{
		while (s[pos] == c)
			pos++;
		if (s[pos] != c && s[pos] != '\0')
			count++;
		while (s[pos] != c && s[pos] != '\0')
			pos++;
	}
	return (count);
}
