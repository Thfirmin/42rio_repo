/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llima <llima@student.42.rio>               +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/03 04:38:40 by llima             #+#    #+#             */
/*   Updated: 2022/06/03 05:06:17 by llima            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t	ft_strlcat(char *dst, const char *src, size_t size)
{
	unsigned int	total_size;
	unsigned int	append;

	total_size = ft_strlen(dst);
	append = size - total_size - 1;
	if (dst == NULL && src == NULL)
		return (0);
	if (size <= total_size)
		return (ft_strlen(src) + size);
	while (*src != '\0' && append > 0)
	{
		dst[total_size] = *src;
		total_size++;
		src++;
		append--;
	}
	dst[total_size] = '\0';
	return (ft_strlen(src) + ft_strlen(dst));
}
