/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf_ptr.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sgomes-d <sgomes-d@student.42.rio>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/23 02:33:33 by sgomes-d          #+#    #+#             */
/*   Updated: 2022/06/23 02:33:47 by sgomes-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

void	ft_putptr(uintptr_t num)
{
	if (num >= 16)
	{
		ft_putptr(num / 16);
		num %= 16;
	}
	if (num < 10)
		ft_putchar(num + '0');
	else
		ft_putchar(num - 10 + 'a');
}

int	ft_ptrlen(uintptr_t num)
{
	int	result;

	result = 0;
	while (num != 0)
	{
		result++;
		num /= 16;
	}
	return (result);
}

int	ft_print_ptr(unsigned long long ptr)
{
	int	result;

	result = 0;
	result += write(1, "0x", 2);
	if (ptr == 0)
		return (result += ft_putchar('0'));
	ft_putptr(ptr);
	result += ft_ptrlen(ptr);
	return (result);
}
