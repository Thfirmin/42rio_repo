/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_utoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: sgomes-d <sgomes-d@student.42.rio>         +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/23 02:49:43 by sgomes-d          #+#    #+#             */
/*   Updated: 2022/06/23 02:50:10 by sgomes-d         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

static int	get_len(unsigned int n)
{
	size_t	result;

	result = 0;
	while (n)
	{
		result++;
		n /= 10;
	}
	return (result);
}

static char	*generate(char *result, long n, int len)
{
	if (n == 0)
		return (result = ft_strdup("0"));
	result[len] = '\0';
	while (len)
	{
		result[len - 1] = (n % 10) + '0';
		n /= 10;
		len--;
	}
	return (result);
}

char	*ft_utoa(unsigned int n)
{
	int		len;
	char	*result;

	len = get_len(n);
	result = malloc(sizeof(char) * (len + 1));
	if (!result)
		return (0);
	result = generate(result, n, len);
	if (!result)
		return (0);
	return (result);
}
