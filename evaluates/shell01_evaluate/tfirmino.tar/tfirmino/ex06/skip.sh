ls -l | sed --silent '1~2p'
