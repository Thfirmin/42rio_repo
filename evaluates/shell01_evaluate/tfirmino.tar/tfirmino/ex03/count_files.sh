find . | wc -l
