touch aparece{1,3,5}
touch .naoaparece{1,3}
mkdir aparece{2,4,6}
mkdir .naoaparece{2,4}
touch -a aparece1
touch -at 10011010 .naoaparece1
touch -at 10021010 aparece2
touch -at 10031010 .naoaparece2
touch -at 10041010 aparece3
touch -at 10051010 .naoaparece3
touch -at 10061010 aparece4
touch -at 10071010 .naoaparece4
touch -at 10081010 aparece5
touch -at 10091010 aparece6
#rm -rf aparece{1..6}
#rm -rf .naoaparece{1..4}
