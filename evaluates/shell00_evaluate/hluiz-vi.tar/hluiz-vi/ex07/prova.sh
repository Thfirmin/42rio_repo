mkdir hi 'hi2~'
touch apagar~ '#apagar#'
touch teste2
touch hi/apagar2~
touch hi/'#apagar2#'
touch hi/hi2
touch hi2~/oi
touch hi2~/~app~
