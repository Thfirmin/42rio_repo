#!/bin/sh
git ls-files --other --ignored --exclude-standard
