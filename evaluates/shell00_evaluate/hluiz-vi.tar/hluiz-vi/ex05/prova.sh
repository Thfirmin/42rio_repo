touch .DS_Store
touch mywork.c
touch test
#rm -rf .gitiginore .DS_Store mywork.c test
