tar -xf testShell00.tar
ls -l
#rm -rf testShell00
echo '-r--r-xr-x 1 XX   XX      40 Jun  1 23:42 testShell00'
