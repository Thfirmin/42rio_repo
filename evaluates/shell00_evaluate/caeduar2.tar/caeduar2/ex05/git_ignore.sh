#!/bin/sh
git check-ignore *
