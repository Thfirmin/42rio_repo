#include "get_next_line.h"
#include <stdio.h>
#include <fcntl.h>

int	main(void)
{
	int	fd;
	char	*str;

	fd = open("okla.txt", O_RDONLY);	
	str = get_next_line(fd);
	close (fd);
	printf("%s", str);
}
