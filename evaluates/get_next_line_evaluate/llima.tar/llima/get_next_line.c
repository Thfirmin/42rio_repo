/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   get_next_line.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: llima <llima@student.42.rio>               +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/06/19 00:19:17 by llima             #+#    #+#             */
/*   Updated: 2022/06/19 00:57:15 by llima            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "get_next_line.h"

void	update_buffer(char *buffer, int brpos, int blen)
{
	int	i;

	i = 0;
	while (brpos + 1 < blen)
	{
		buffer[i] = buffer[brpos + 1];
		i++;
		brpos++;
	}
	buffer[i] = '\0';
}

char	*prepare_line(char *line, int brpos)
{
	char	*s3;
	int		lenline;
	int		i;

	if (line == NULL)
		lenline = 0;
	else
		lenline = ft_strlen(line);
	i = 0;
	s3 = malloc(lenline + brpos + 1);
	if (s3 == NULL)
		return (NULL);
	while (i < lenline)
	{
		s3[i] = line[i];
		i++;
	}
	s3[lenline] = '\0';
	if (line != NULL)
		free(line);
	return (s3);
}

char	*get_line(char *line, char *buffer, int blen)
{
	int	brpos;
	int	lenline;
	int	i;

	brpos = 0;
	i = 0;
	while (buffer[brpos] != '\n' && brpos + 1 < blen)
		brpos++;
	line = prepare_line(line, brpos + 1);
	lenline = ft_strlen(line);
	while (i <= brpos)
	{
		line[lenline] = buffer[i];
		lenline++;
		i++;
	}
	update_buffer(buffer, brpos, blen);
	line[lenline] = '\0';
	return (line);
}

char	*get_next_line(int fd)
{
	static char	buffer[BUFFER_SIZE];
	char		*line;
	static int	blen;

	if (fd < 0)
		return (NULL);
	line = NULL;
	while (1)
	{
		if (buffer[0] != '\0')
		{
			line = get_line(line, buffer, blen);
			blen = ft_strlen(buffer);
			if (blen != 0 || line[ft_strlen(line) - 1] == '\n')
				return (line);
		}
		blen = read (fd, buffer, BUFFER_SIZE);
		if (blen == 0 && line != NULL)
			return (line);
		if (blen == 0 || blen == -1)
			return (NULL);
	}
}
