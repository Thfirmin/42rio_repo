Cronologia:

I.	Eu Aceito;

II.	Shell (00 e 01);

III.	C (00 até 02);

IV.	Rush00;

V.	Sastantua;

VI.	C (03 até 05);

VII.	Match-N-Match;

VIII.	C 06;

IX.	Rush01;

X.	C 07;

XI.	EvalExpr;

XII.	C (08 até 10);

XIII.	Rush02;

XIV.	C (11 até 13);

XV.	Projeto final BSQ.

