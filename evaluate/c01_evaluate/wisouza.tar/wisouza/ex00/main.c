#include <stdio.h>

void	ft_ft(int *nbr);

int	main(void)
{
	int	valor;
	ft_ft(&valor);
	printf ("%d", valor);
	return (0);
}
