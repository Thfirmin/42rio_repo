/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush01.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: coder <coder@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/05 hh:mm:ss by coder             #+#    #+#             */
/*   Updated: 2022/02/05 hh:mm:ss by coder            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	ft_putchar(char c);

void	ft_print(int col, char char_inicial, char char_medio, char char_final);

void	rush(int x, int y)
{
	int	contador_linha;

	contador_linha = 1;
	if (x >= 1 && y >= 1)
	{
		while (contador_linha <= y)
		{
			if (contador_linha == 1)
				ft_print(x, '/', '*', '\\');
			else if (contador_linha == y)
				ft_print(x, '\\', '*', '/');
			else
				ft_print(x, '*', ' ', '*');
			contador_linha++;
		}
	}
}

void	ft_print(int col, char char_inicial, char char_medio, char char_final)
{
	int	contador_coluna;

	contador_coluna = 1;
	while (contador_coluna <= col)
	{
		if (contador_coluna == 1)
			ft_putchar(char_inicial);
		else if (contador_coluna == col)
			ft_putchar(char_final);
		else
			ft_putchar(char_medio);
		contador_coluna++;
	}
	ft_putchar('\n');
}
