/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rush00.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: coder <coder@student.42.fr>                +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/05 hh:mm:ss by coder             #+#    #+#             */
/*   Updated: 2022/02/05 hh:mm:ss by coder            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c);

void	rush(int x, int y)
{
	int	px;
	int	py;

	py = 1;
	//if (x <= 0 || y <= 0)

	while (py <= y)
	{
		px = 1;
		while (px <= x)
		{
			if ((px > 1 && px < x) && (py == 1 || py == y))
				ft_putchar('-');
			else if ((px == 1 || px == x) && (py > 1 && py < y))
				ft_putchar('|');
			else if ((px > 1 && px < x) && (py > 1 && py < y))
				ft_putchar(' ');
			else
				ft_putchar('o');
			px ++;
		}
		py ++;
		write (1, "\n", 1);
	}
}
