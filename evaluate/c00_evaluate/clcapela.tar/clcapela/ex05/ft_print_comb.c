/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thfirmin <thiagofirmino2001@gmail.com>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/10 00:18:37 by clcapela          #+#    #+#             */
/*   Updated: 2022/02/11 04:58:01 by thfirmin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	ft_print_comb(void)
{
	int	one;
	int	two;
	int	three;

	one = '0';
	while (one <= '7')
	{
		two = one + 1;
		while (two <= '8')
		{
			three = two + 1;
			while (three <= '9')
			{
				ft_putchar(one);
				ft_putchar(two);
				ft_putchar(three);
				if (one != '7')
					write(1, ", ", 2);
				three++;
			}
			two++;
		}
		one++;
	}
}

int	main(void)
{
	ft_print_comb();
	return(0);
}