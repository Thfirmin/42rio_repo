/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: thfirmin <thiagofirmino2001@gmail.com>     +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/10 03:00:09 by clcapela          #+#    #+#             */
/*   Updated: 2022/02/11 05:14:24 by thfirmin         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_putchar(char c)
{
	write(1, &c, 1);
}

void	counter(int c)
{
	int	cl;

	cl = 0;
	cl = c / 10 + '0';
	ft_putchar(cl);
	cl = c % 10 + '0';
	ft_putchar(cl);
}

void	ft_print_comb2(void)
{	
	int	x;
	int	y;

	x = 0;
	while (x <= 98)
	{
		y = x + 1;
		while (y <= 99)
		{
			counter(x);
			write(1, " ", 1);
			counter(y);
			if (x != 98)
				write(1, ", ", 2);
			y++;
		}
	x++;
	}
}

int	main(void)
{
	ft_print_comb2();
	return(0);
}