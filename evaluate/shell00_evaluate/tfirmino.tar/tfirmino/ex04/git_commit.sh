git log --max-count=5 --pretty=tformat:%H
