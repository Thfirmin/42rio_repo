git ls-files -io --exclude-standard
