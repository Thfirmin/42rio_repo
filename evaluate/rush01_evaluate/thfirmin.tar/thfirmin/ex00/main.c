/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: coder <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/14 01:24:35 by coder             #+#    #+#             */
/*   Updated: 2022/02/14 01:24:41 by coder            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdlib.h>

int		validate_solution(int *col_up, int *col_down, int **po_sol, int *ids);
int		validate_solutions(int *po_sol_id, int *col_up, int *col_down, int **po_sol);
void	ft_get_from_matrix(int **vec, int **matrix, int i);
void	ft_build_all_sol(int **po_sol, int *rw_l, int *rw_r, int *po_sol_id);
int		is_valid(int *try, int viewer);
int		*ids(int i, int j, int k, int l);
int		check_repeated_elements(int *str);
int		*reverse(int *str);
void	print_matrix(int matrix[4][4]);
void	init_matrix(int ***matrix, int m, int n);
void	perm_recursive(int *str, int k, int *u, int **comb);
void	swap_char(int *str, int p1, int p2);
void	init_combinations(int **comb);

void	solver(int *col_up, int *col_down, int *rw_l, int *rw_r)
{
	int	**po_sol;
	int	*solutions_id;
	int	i;

	i = -1;
	init_matrix(&po_sol, 4, 24 * 4);
	solutions_id = (int *)malloc(4 * sizeof(int));
	while (++i < 4)
	{
		solutions_id[i] = 0;
	}
	ft_build_all_sol(po_sol, rw_l, rw_r, solutions_id);
	if (!(validate_solutions(solutions_id, col_up, col_down, po_sol)))
		write(1, "Error\n", 6);
	free(solutions_id);
	free(po_sol);
}

int str_len(char* str)
{
  int i;

  i = 0;
  while (str[i] != '\0')
  {
    i++;
  }
  return i;
}

int	main(int argc, char **argv)
{
	int* col_up = (int*)malloc(4 * sizeof(int));
	int* col_down = (int*)malloc(4 * sizeof(int));
	int* row_left = (int*)malloc(4 * sizeof(int));
	int* row_right = (int*)malloc(4 * sizeof(int));
	char* str; 
	if (argc != 2)
	{
		write(1, "Error\n", 6);
		return (0);
	}
	str = *(argv + 1);
	if (str_len(str) != 31)
	{
		write(1, "Error\n", 6);
		return (0);
	}
	while (*(str + 23) != '\0')
	{
		*col_up++ = *str - '0';
		*col_down++ = *(str + 8) - '0';
		*row_left++ = *(str + 16) - '0';
		*row_right++ = *(str + 24) - '0';
		str = str + 2;
	}
	solver(col_up-4, col_down-4, row_left-4, row_right-4);
	return (1);

}