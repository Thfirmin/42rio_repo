/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: coder <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/14 00:08:35 by coder             #+#    #+#             */
/*   Updated: 2022/02/14 00:08:40 by coder            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdlib.h>
#include <unistd.h>

void	print_matrix(int matrix[4][4]);
void	init_matrix(int ***matrix, int m, int n);
int		*ids(int i, int j, int k, int l);
int		check_repeated_elements(int	*str);
int		*reverse(int	*str);

int	*ids(int i, int j, int k, int l)
{
	int	*ids;

	ids = (int *)malloc(4 * sizeof(int));
	ids[0] = i;
	ids[1] = j;
	ids[2] = k;
	ids[3] = l;
	return (ids);
}

int	check_repeated_elements(int *str)
{
	int	i;
	int	j;

	i = 0;
	while (i < 4)
	{
		j = i + 1;
		while (j < 4)
		{
			if (str[i] == str[j])
				return (1);
			j++;
		}
		i++;
	}
	return (0);
}

int	*reverse(int	*str)
{
	int	temp1;
	int	temp2;

	temp1 = str[0];
	temp2 = str[1];
	str[0] = str[3];
	str[1] = str[2];
	str[2] = temp2;
	str[3] = temp1;
	return (str);
}

void	print_matrix(int matrix[4][4])
{
	int		i;
	int		j;
	char	num;

	i = 0;
	j = 0;
	while (i < 4)
	{
		j = 0;
		while (j < 4)
		{
			num = matrix[i][j] + '0';
			write(1, &num, 1);
			if (j != 3)
				write(1, " ", 1);
			j++;
		}
		write(1, "\n", 1);
		i++;
	}
}

void	init_matrix(int ***matrix, int m, int n)
{
	int	i;
	int	j;

	i = 0;
	*matrix = (int **)malloc(m * sizeof(int *));
	while (i < m)
	{
		*(*matrix + i) = (int *)malloc(n * sizeof(int));
		i++;
	}
	i = 0;
	j = 0;
	while (i < m)
	{
		j = 0;
		while (j < n)
		{
			(*matrix)[i][j] = 0;
			j++;
		}
		i++;
	}
}
