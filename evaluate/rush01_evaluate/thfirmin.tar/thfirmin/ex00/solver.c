/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   solver.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: coder <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/14 00:40:55 by coder             #+#    #+#             */
/*   Updated: 2022/02/14 00:41:06 by coder            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>
#include <stdlib.h>

int		validate_solution(int *cl_u, int *cl_d, int **pos_solu, int *ids);
int		validate_solutions(int *p_s_id, int *cl_u, int *cl_d, int **pos_solu);
void	ft_get_from_matrix(int *vec, int **matrix, int i);
void	ft_build_all_sol(int **pos_solu, int *rw_l, int *rw_r, int *p_s_id);
int		is_valid(int *try, int viewer);
int		*reverse(int *str);
void	print_matrix(int matrix[4][4]);
int		*ids(int i, int j, int k, int l);
void	init_matrix(int ***matrix, int m, int n);
void	init_combinations(int **comb);
int		check_repeated_elements(int *str);

int	validate_solution(int *cl_u, int *cl_d, int **pos_solu, int *ids)
{
	int	n;
	int	matrix_solution[4][4];
	int	try[4];

	n = -1;
	while (++n < 4)
	{
		try[0] = pos_solu[0][n + 4 * ids[0]];
		try[1] = pos_solu[1][n + 4 * ids[1]];
		try[2] = pos_solu[2][n + 4 * ids[2]];
		try[3] = pos_solu[3][n + 4 * ids[3]];
		if (is_valid(try, cl_u[n]) && is_valid(reverse(try), cl_d[n]))
		{
			matrix_solution[0][n] = pos_solu[0][n + 4 * ids[0]];
			matrix_solution[1][n] = pos_solu[1][n + 4 * ids[1]];
			matrix_solution[2][n] = pos_solu[2][n + 4 * ids[2]];
			matrix_solution[3][n] = pos_solu[3][n + 4 * ids[3]];
		}
		else
			return (0);
	}
	print_matrix(matrix_solution);
	free(ids);
	return (1);
}

int	validate_solutions(int *p_s_id, int *cl_u, int *cl_d, int **pos_solu)
{
	int	i;
	int	j;
	int	k;
	int	l;

	i = -1;
	while (++i < p_s_id[0])
	{
		j = -1;
		while (++j < p_s_id[1])
		{
			k = -1;
			while (++k < p_s_id[2])
			{
				l = -1;
				while (++l < p_s_id[3])
				{
					if (validate_solution(cl_u, cl_d, pos_solu, ids(i, j, k, l)))
						return (1);
				}
			}
		}
	}
	return (0);
}

void	ft_get_from_matrix(int *vec, int **matrix, int i)
{
	int	j;

	j = 0;
	while (j < 4)
	{
		vec[j] = matrix[i][j];
		j++;
	}
}

void	ft_build_all_sol(int **pos_solu, int *rw_l, int *rw_r, int *p_s_id)
{
	int	i;
	int	j;
	int	try[4];
	int	*pos_solu_row;
	int	**all_permutations;

	init_matrix(&all_permutations, 24, 4);
	init_combinations(all_permutations);
	i = -1;
	while (++i < 4)
	{
		pos_solu_row = *(pos_solu + i);
		j = -1;
		while (++j < 24)
		{
			ft_get_from_matrix(try, all_permutations, j);
			if (is_valid(try, rw_l[i]) && is_valid(reverse(try), rw_r[i]))
			{
				p_s_id[i]++;
				ft_get_from_matrix(pos_solu_row, all_permutations, j);
				pos_solu_row = pos_solu_row + 4;
			}
		}
	}
	free(all_permutations);
}

int	is_valid(int *try, int viewer)
{
	int	count;
	int	i;
	int	first;
	int	next;

	if (check_repeated_elements(try))
		return (0);
	i = 0;
	count = 1;
	first = try[0];
	while (i < 3)
	{
		next = try[i + 1];
		if (next > first)
		{
			first = next;
			count++;
		}
	i++;
	}
	return (count == viewer);
}
