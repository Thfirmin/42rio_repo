/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   buld_permutations.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: coder <marvin@42.fr>                       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2022/02/14 02:23:56 by coder             #+#    #+#             */
/*   Updated: 2022/02/14 02:24:01 by coder            ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

void	perm_recursive(int *list, int k, int *u, int **comb);
void	swap_char(int *list, int p1, int p2);
void	init_combinations(int **comb);

void	perm_recursive(int *list, int k, int *u, int **comb)
{
	int	i;

	if (k == 4)
	{
		comb[*u][0] = list[0];
		comb[*u][1] = list[1];
		comb[*u][2] = list[2];
		comb[*u][3] = list[3];
		(*u)++;
	}
	else
	{
		i = k;
		while (i < 4)
		{
			swap_char(list, k, i);
			perm_recursive(list, k + 1, u, comb);
			swap_char(list, i, k);
			i++;
		}
	}
}

void	swap_char(int *list, int p1, int p2)
{
	int	tmp;

	tmp = list[p1];
	list[p1] = list[p2];
	list[p2] = tmp;
}

void	init_combinations(int **comb)
{
	int	list[4];
	int	u;

	u = 0;
	list[0] = 1;
	list[1] = 2;
	list[2] = 3;
	list[3] = 4;
	perm_recursive(list, 0, &u, comb);
}
